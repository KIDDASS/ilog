const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcryptjs');

class Database {
    constructor() {
        this.db = new sqlite3.Database(path.join(__dirname, 'memories.db'));
        this.initTables();
    }

    async initTables() {
        return new Promise((resolve, reject) => {
            this.db.serialize(() => {
                // Users table
                this.db.run(`
                    CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        username TEXT UNIQUE NOT NULL,
                        email TEXT UNIQUE NOT NULL,
                        password TEXT NOT NULL,
                        role TEXT DEFAULT 'member',
                        can_post INTEGER DEFAULT 0,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                    )
                `);

                // Memories table
                this.db.run(`
                    CREATE TABLE IF NOT EXISTS memories (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        title TEXT NOT NULL,
                        description TEXT,
                        image_url TEXT NOT NULL,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users (id)
                    )
                `);

                // Create default admin user
                this.db.get('SELECT * FROM users WHERE username = ?', ['admin'], async (err, row) => {
                    if (!row) {
                        const hashedPassword = await bcrypt.hash('admin123', 12);
                        this.db.run(
                            'INSERT INTO users (username, email, password, role, can_post) VALUES (?, ?, ?, ?, ?)',
                            ['admin', 'admin@memories.com', hashedPassword, 'admin', 1]
                        );

                        // Create demo member
                        const memberPassword = await bcrypt.hash('member123', 12);
                        this.db.run(
                            'INSERT INTO users (username, email, password, role, can_post) VALUES (?, ?, ?, ?, ?)',
                            ['member', 'member@memories.com', memberPassword, 'member', 1]
                        );
                    }
                });

                resolve();
            });
        });
    }

    async getUserByUsername(username) {
        return new Promise((resolve, reject) => {
            this.db.get('SELECT * FROM users WHERE username = ?', [username], (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });
    }

    async getUserByEmail(email) {
        return new Promise((resolve, reject) => {
            this.db.get('SELECT * FROM users WHERE email = ?', [email], (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });
    }

    async getUserById(id) {
        return new Promise((resolve, reject) => {
            this.db.get('SELECT * FROM users WHERE id = ?', [id], (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });
    }

    async createUser(userData) {
        return new Promise((resolve, reject) => {
            const { username, email, password, role, can_post } = userData;
            this.db.run(
                'INSERT INTO users (username, email, password, role, can_post) VALUES (?, ?, ?, ?, ?)',
                [username, email, password, role, can_post ? 1 : 0],
                function(err) {
                    if (err) reject(err);
                    else resolve(this.lastID);
                }
            );
        });
    }

    async getAllUsers() {
        return new Promise((resolve, reject) => {
            this.db.all(
                'SELECT id, username, email, role, can_post, created_at FROM users ORDER BY created_at DESC',
                [],
                (err, rows) => {
                    if (err) reject(err);
                    else resolve(rows.map(row => ({ ...row, can_post: !!row.can_post })));
                }
            );
        });
    }

    async updateUserPermission(userId, canPost) {
        return new Promise((resolve, reject) => {
            this.db.run(
                'UPDATE users SET can_post = ? WHERE id = ?',
                [canPost ? 1 : 0, userId],
                (err) => {
                    if (err) reject(err);
                    else resolve();
                }
            );
        });
    }

    async getMemories() {
        return new Promise((resolve, reject) => {
            this.db.all(`
                SELECT m.*, u.username 
                FROM memories m 
                JOIN users u ON m.user_id = u.id 
                ORDER BY m.created_at DESC
            `, [], (err, rows) => {
                if (err) reject(err);
                else resolve(rows);
            });
        });
    }

    async createMemory(memoryData) {
        return new Promise((resolve, reject) => {
            const { user_id, title, description, image_url } = memoryData;
            this.db.run(
                'INSERT INTO memories (user_id, title, description, image_url) VALUES (?, ?, ?, ?)',
                [user_id, title, description, image_url],
                function(err) {
                    if (err) reject(err);
                    else resolve(this.lastID);
                }
            );
        });
    }

    async getMemoryById(id) {
        return new Promise((resolve, reject) => {
            this.db.get(`
                SELECT m.*, u.username 
                FROM memories m 
                JOIN users u ON m.user_id = u.id 
                WHERE m.id = ?
            `, [id], (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });
    }
}

module.exports = Database;